"""
Resilience and fault tolerance components.
Includes circuit breakers, rate limiting, connection limiting, system protection, and timeouts.
"""