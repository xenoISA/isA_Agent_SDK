"""
Core infrastructure modules for the application.
Contains resilience, error handling, and configuration components.
"""