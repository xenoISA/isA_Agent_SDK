Old HIL service implementations archived here
